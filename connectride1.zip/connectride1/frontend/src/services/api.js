import axios from 'axios';

const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:8000/index.php';

const api = axios.create({
    baseURL: API_BASE,
    timeout: 10000,
    headers: {
        'Content-Type': 'application/json',
    },
});

// Request interceptor for auth token
api.interceptors.request.use(
    (config) => {
        const token = localStorage.getItem('token');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => Promise.reject(error)
);

// Response interceptor for token handling
api.interceptors.response.use(
    (response) => {
        // Store token if received
        if (response.data.token) {
            localStorage.setItem('token', response.data.token);
            localStorage.setItem('userId', response.data.user_id);
        }
        return response;
    },
    (error) => {
        // Handle 401 - clear token
        if (error.response?.status === 401) {
            localStorage.removeItem('token');
            localStorage.removeItem('userId');
            window.location.href = '/';
        }
        return Promise.reject(error);
    }
);

export const createProfile = async (data) => {
    return api.post(`?action=profile`, data);
};

export const findMatches = async (data) => {
    return api.post(`?action=matches`, data);
};

export const bookRide = async (data) => {
    return api.post(`?action=ride`, data);
};

export const getRides = async (userId) => {
    return api.get(`?action=rides`);
};

export const healthCheck = async () => {
    return api.get(`?action=health`);
};

export default api;