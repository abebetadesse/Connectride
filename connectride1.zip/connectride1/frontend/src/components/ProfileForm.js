import React, { useState } from 'react';
import {
    Box,
    TextField,
    Button,
    Typography,
    Card,
    CardContent,
    Alert,
    CircularProgress,
} from '@mui/material';
import { createProfile } from '../services/api';

const ProfileForm = ({ setUserId, setToken }) => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        interests: '',
        vehicle: '',
        password: '',
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
        // Clear error when user types
        if (error) setError('');
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        setSuccess('');

        try {
            const response = await createProfile(formData);
            setSuccess(response.data.message);
            localStorage.setItem('userId', response.data.user_id);
            localStorage.setItem('token', response.data.token);
            setUserId(response.data.user_id);
            setToken(response.data.token);
            
            // Clear form
            setFormData({ name: '', email: '', interests: '', vehicle: '', password: '' });
            
            // Auto-redirect after 2 seconds
            setTimeout(() => {
                window.location.href = '/matches';
            }, 2000);
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to create profile');
        } finally {
            setLoading(false);
        }
    };

    return (
        <Box className="app-container">
            <Card className="card">
                <CardContent>
                    <Typography variant="h4" gutterBottom align="center" color="primary">
                        Create Your Profile
                    </Typography>
                    <Typography variant="body1" gutterBottom align="center" color="textSecondary">
                        Join ConnectRide and start connecting with others!
                    </Typography>

                    {error && <Alert severity="error" className="error">{error}</Alert>}
                    {success && <Alert severity="success" className="success">{success}</Alert>}

                    <Box component="form" onSubmit={handleSubmit} sx={{ mt: 2 }}>
                        <TextField
                            fullWidth
                            margin="normal"
                            label="Full Name"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            required
                            variant="outlined"
                        />
                        
                        <TextField
                            fullWidth
                            margin="normal"
                            label="Email Address"
                            name="email"
                            type="email"
                            value={formData.email}
                            onChange={handleChange}
                            required
                            variant="outlined"
                        />
                        
                        <TextField
                            fullWidth
                            margin="normal"
                            label="Interests (comma-separated)"
                            name="interests"
                            value={formData.interests}
                            onChange={handleChange}
                            placeholder="hiking, music, travel"
                            variant="outlined"
                            helperText="Help us find great matches for you!"
                        />
                        
                        <TextField
                            fullWidth
                            margin="normal"
                            label="Vehicle Type (optional)"
                            name="vehicle"
                            value={formData.vehicle}
                            onChange={handleChange}
                            placeholder="Car, Bike, Public Transport"
                            variant="outlined"
                            helperText="For ride-sharing preferences"
                        />
                        
                        <TextField
                            fullWidth
                            margin="normal"
                            label="Password"
                            name="password"
                            type="password"
                            value={formData.password}
                            onChange={handleChange}
                            required
                            variant="outlined"
                        />
                        
                        <Button
                            type="submit"
                            fullWidth
                            variant="contained"
                            color="primary"
                            disabled={loading}
                            sx={{ mt: 3, mb: 2 }}
                        >
                            {loading ? <CircularProgress size={24} /> : 'Create Profile'}
                        </Button>
                    </Box>
                </CardContent>
            </Card>
        </Box>
    );
};

export default ProfileForm;