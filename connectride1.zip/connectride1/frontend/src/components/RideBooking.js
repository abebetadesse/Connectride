import React, { useState } from 'react';
import {
    Box,
    TextField,
    Button,
    Typography,
    Card,
    CardContent,
    Alert,
    CircularProgress,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { bookRide } from '../services/api';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import 'leaflet-control-geocoder/dist/Control.Geocoder.css';
import 'leaflet-control-geocoder/dist/Control.Geocoder.js';

// Fix for default marker icon in Leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
    iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
    iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
    shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

const RideBooking = ({ userId }) => {
    const [formData, setFormData] = useState({
        pickup: '',
        dropoff: '',
        lat_pickup: null,
        lng_pickup: null,
        lat_dropoff: null,
        lng_dropoff: null,
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
        if (error) setError('');
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        setSuccess('');

        try {
            const response = await bookRide(formData);
            setSuccess(response.data.message);
            
            setTimeout(() => {
                navigate(`/track/${response.data.ride_id}`);
            }, 2000);
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to book ride');
        } finally {
            setLoading(false);
        }
    };
    
    // Custom hook to handle map clicks for setting markers
    const MapClickHandler = () => {
        const map = useMapEvents({
            click: (e) => {
                const { lat, lng } = e.latlng;
                if (!formData.lat_pickup) {
                    setFormData(prev => ({
                        ...prev,
                        lat_pickup: lat,
                        lng_pickup: lng,
                    }));
                } else if (!formData.lat_dropoff) {
                    setFormData(prev => ({
                        ...prev,
                        lat_dropoff: lat,
                        lng_dropoff: lng,
                    }));
                }
            }
        });
        return null;
    };

    if (!userId) return <Alert severity="warning">Please create a profile to book a ride.</Alert>;

    return (
        <Box className="app-container">
            <Card className="card">
                <CardContent>
                    <Typography variant="h4" gutterBottom align="center" color="primary">
                        Book a Ride
                    </Typography>
                    
                    {error && <Alert severity="error" className="error">{error}</Alert>}
                    {success && <Alert severity="success" className="success">{success}</Alert>}

                    <Box component="form" onSubmit={handleSubmit} sx={{ mt: 2 }}>
                        <TextField
                            fullWidth
                            margin="normal"
                            label="Pickup Location"
                            name="pickup"
                            value={formData.pickup}
                            onChange={handleChange}
                            required
                            variant="outlined"
                        />
                        <TextField
                            fullWidth
                            margin="normal"
                            label="Drop-off Location"
                            name="dropoff"
                            value={formData.dropoff}
                            onChange={handleChange}
                            required
                            variant="outlined"
                        />
                        <Box sx={{ my: 2 }} className="map-container">
                            <MapContainer 
                                center={[34.052235, -118.243683]} 
                                zoom={10} 
                                style={{ height: '100%', width: '100%' }}
                            >
                                <TileLayer
                                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                                    attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
                                />
                                {formData.lat_pickup && formData.lng_pickup && (
                                    <Marker position={[formData.lat_pickup, formData.lng_pickup]} />
                                )}
                                {formData.lat_dropoff && formData.lng_dropoff && (
                                    <Marker position={[formData.lat_dropoff, formData.lng_dropoff]} />
                                )}
                                <MapClickHandler />
                            </MapContainer>
                        </Box>
                        <Button
                            type="submit"
                            fullWidth
                            variant="contained"
                            color="primary"
                            disabled={loading}
                            sx={{ mt: 3, mb: 2 }}
                        >
                            {loading ? <CircularProgress size={24} /> : 'Book Ride'}
                        </Button>
                    </Box>
                </CardContent>
            </Card>
        </Box>
    );
};

export default RideBooking;