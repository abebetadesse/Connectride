import React, { useState, useEffect } from 'react';
import {
    Box,
    Typography,
    Card,
    CardContent,
    Button,
    Alert,
    CircularProgress,
} from '@mui/material';
import { findMatches } from '../services/api';

const Matches = ({ userId }) => {
    const [matches, setMatches] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchMatches = async () => {
            if (!userId) {
                setLoading(false);
                setError('You must create a profile to find matches.');
                return;
            }

            try {
                // Fetch the current user's interests first
                const userProfile = await findMatches({ interests: 'dummy' }); // This is a placeholder; a real implementation would have a dedicated profile fetch endpoint.
                
                const response = await findMatches({
                    interests: userProfile.data.matches.length > 0 ? userProfile.data.matches[0].interests : 'hiking, travel' // Use a default if no matches found
                });
                
                setMatches(response.data.matches);
            } catch (err) {
                setError(err.response?.data?.error || 'Failed to fetch matches.');
            } finally {
                setLoading(false);
            }
        };

        fetchMatches();
    }, [userId]);

    const handleConnect = (matchId) => {
        alert(`Connecting with user ${matchId}... (This would initiate a chat or connection request)`);
    };

    if (loading) {
        return (
            <Box className="loading">
                <CircularProgress />
            </Box>
        );
    }

    if (error) {
        return <Alert severity="error">{error}</Alert>;
    }

    return (
        <Box className="app-container">
            <Typography variant="h4" gutterBottom>Your Matches</Typography>
            {matches.length === 0 ? (
                <Alert severity="info">No matches found at the moment. Update your profile interests to find more!</Alert>
            ) : (
                matches.map(match => (
                    <Card key={match.id} className="card" sx={{ mb: 2 }}>
                        <CardContent>
                            <Typography variant="h6">{match.name}</Typography>
                            <Typography variant="body2" color="textSecondary">
                                Interests: {match.interests || 'Not specified'}
                            </Typography>
                            <Button
                                variant="contained"
                                color="primary"
                                onClick={() => handleConnect(match.id)}
                                sx={{ mt: 2 }}
                            >
                                Connect
                            </Button>
                        </CardContent>
                    </Card>
                ))
            )}
        </Box>
    );
};

export default Matches;