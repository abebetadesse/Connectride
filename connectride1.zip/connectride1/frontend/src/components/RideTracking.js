import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import {
    Box,
    Typography,
    Card,
    CardContent,
    Alert,
    CircularProgress,
} from '@mui/material';
import { MapContainer, TileLayer, Marker, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { io } from 'socket.io-client';
import Kalman from 'kalmanjs';

const SOCKET_URL = process.env.REACT_APP_SOCKET_URL || 'http://localhost:4000';

const kalmanLat = new Kalman({ R: 0.01, Q: 3 });
const kalmanLng = new Kalman({ R: 0.01, Q: 3 });

const RecenterMap = ({ center }) => {
    const map = useMap();
    useEffect(() => {
        if (center) {
            map.flyTo(center, map.getZoom());
        }
    }, [center, map]);
    return null;
};

const RideTracking = () => {
    const { rideId } = useParams();
    const [rideData, setRideData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [driverLocation, setDriverLocation] = useState(null);

    useEffect(() => {
        const socket = io(SOCKET_URL);

        socket.on('connect', () => {
            console.log('Connected to socket server');
            socket.emit('track_ride', { rideId });
        });

        socket.on('location_update', (data) => {
            if (data.ride_id === rideId) {
                // Apply Kalman filter for smooth tracking
                const smoothedLat = kalmanLat.filter(data.lat);
                const smoothedLng = kalmanLng.filter(data.lng);
                setDriverLocation({ lat: smoothedLat, lng: smoothedLng });
                setLoading(false);
            }
        });

        socket.on('ride_status_update', (data) => {
            if (data.ride_id === rideId) {
                setRideData(prev => ({ ...prev, status: data.status }));
            }
        });

        socket.on('disconnect', () => {
            console.log('Disconnected from socket server');
        });

        return () => {
            socket.disconnect();
        };
    }, [rideId]);

    if (loading) return <Box className="loading"><CircularProgress /><Typography>Waiting for driver to start ride...</Typography></Box>;
    if (error) return <Alert severity="error">{error}</Alert>;
    
    return (
        <Box className="app-container">
            <Card className="card">
                <CardContent>
                    <Typography variant="h4" gutterBottom>Tracking Ride #{rideId}</Typography>
                    <Typography variant="body1" gutterBottom>Status: {rideData?.status || 'Booked'}</Typography>
                    
                    <Box sx={{ my: 2 }} className="map-container">
                        <MapContainer 
                            center={driverLocation || [34.052235, -118.243683]}
                            zoom={15} 
                            style={{ height: '100%', width: '100%' }}
                        >
                            <TileLayer
                                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                                attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
                            />
                            {driverLocation && (
                                <Marker position={driverLocation} />
                            )}
                            <RecenterMap center={driverLocation} />
                        </MapContainer>
                    </Box>
                </CardContent>
            </Card>
        </Box>
    );
};

export default RideTracking;