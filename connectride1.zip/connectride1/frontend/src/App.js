import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useParams } from 'react-router-dom';
import { AppBar, Toolbar, Typography, Container, Box, CircularProgress, Alert } from '@mui/material';
import ProfileForm from './components/ProfileForm';
import Matches from './components/Matches';
import RideBooking from './components/RideBooking';
import RideTracking from './components/RideTracking';
import { api } from './services/api';

const Navigation = ({ userId }) => (
    <AppBar position="static" sx={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }}>
        <Toolbar>
            <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                ConnectRide
            </Typography>
            {userId ? (
                <>
                    <Link to="/" style={{ color: 'white', marginRight: '1rem', textDecoration: 'none' }}>
                        Profile
                    </Link>
                    <Link to="/matches" style={{ color: 'white', marginRight: '1rem', textDecoration: 'none' }}>
                        Matches
                    </Link>
                    <Link to="/ride" style={{ color: 'white', marginRight: '1rem', textDecoration: 'none' }}>
                        Book Ride
                    </Link>
                    <Link to="/rides" style={{ color: 'white', textDecoration: 'none' }}>
                        My Rides
                    </Link>
                </>
            ) : (
                <Link to="/" style={{ color: 'white', textDecoration: 'none' }}>
                    Get Started
                </Link>
            )}
        </Toolbar>
    </AppBar>
);

const Dashboard = ({ userId }) => (
    <Container maxWidth="md" className="app-container">
        <Navigation userId={userId} />
        <Routes>
            <Route path="/" element={<ProfileForm />} />
            <Route path="/matches" element={<Matches userId={userId} />} />
            <Route path="/ride" element={<RideBooking userId={userId} />} />
            <Route path="/rides" element={<UserRides userId={userId} />} />
            <Route path="/track/:rideId" element={<RideTracking />} />
        </Routes>
    </Container>
);

const UserRides = ({ userId }) => {
    const [rides, setRides] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        if (userId) {
            api.getRides(userId)
                .then(response => {
                    setRides(response.data.rides);
                    setLoading(false);
                })
                .catch(err => {
                    setError('Failed to load rides');
                    setLoading(false);
                });
        }
    }, [userId]);

    if (loading) return <CircularProgress />;
    if (error) return <Alert severity="error">{error}</Alert>;

    return (
        <Box>
            <Typography variant="h4" gutterBottom>My Rides</Typography>
            {rides.length === 0 ? (
                <Alert severity="info">No rides booked yet</Alert>
            ) : (
                rides.map(ride => (
                    <Box key={ride.id} className="card">
                        <Typography variant="h6">{ride.pickup} → {ride.dropoff}</Typography>
                        <Typography variant="body2">Status: {ride.status}</Typography>
                        <Typography variant="caption">Booked: {new Date(ride.created_at).toLocaleString()}</Typography>
                        {ride.status === 'booked' && (
                            <Link to={`/track/${ride.id}`}>Track Ride</Link>
                        )}
                    </Box>
                ))
            )}
        </Box>
    );
};

const App = () => {
    const [userId, setUserId] = useState(localStorage.getItem('userId'));
    const [token, setToken] = useState(localStorage.getItem('token'));

    useEffect(() => {
        if (token) {
            api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
        }
    }, [token]);

    return (
        <Router>
            <Dashboard userId={userId} setUserId={setUserId} setToken={setToken} />
        </Router>
    );
};

export default App;