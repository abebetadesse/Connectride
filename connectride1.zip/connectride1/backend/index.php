<?php
declare(strict_types=1);

require_once __DIR__ . '/vendor/autoload.php';

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use ElephantIO\Client;
use ElephantIO\Engine\SocketIO\Version2X;
use Dotenv\Dotenv;

// Load environment variables
$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();

// Configuration
define('DB_HOST', $_ENV['DB_HOST'] ?? 'localhost');
define('DB_NAME', $_ENV['DB_NAME'] ?? 'connectride_db');
define('DB_USER', $_ENV['DB_USER'] ?? 'root');
define('DB_PASS', $_ENV['DB_PASSWORD'] ?? '');
define('JWT_SECRET', $_ENV['JWT_SECRET'] ?? 'your_secret_key');
define('SOCKET_URL', $_ENV['SOCKET_URL'] ?? 'http://localhost:4000');

// Headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: ' . ($_ENV['FRONTEND_URL'] ?? 'http://localhost:3000'));
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Database connection
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit(1);
}

// Initialize database tables
initDatabase($pdo);

// JWT Helpers
function generateJWT(int $userId): string {
    $payload = [
        'user_id' => $userId,
        'iat' => time(),
        'exp' => time() + 3600, // 1 hour
        'iss' => 'connectride'
    ];
    return JWT::encode($payload, JWT_SECRET, 'HS256');
}

function verifyJWT(string $token): ?stdClass {
    try {
        return JWT::decode($token, new Key(JWT_SECRET, 'HS256'));
    } catch (Exception $e) {
        return null;
    }
}

// Database initialization
function initDatabase(PDO $pdo): void {
    $tables = [
        "CREATE TABLE IF NOT EXISTS `users` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `name` varchar(100) NOT NULL,
            `email` varchar(100) NOT NULL UNIQUE,
            `interests` text,
            `vehicle_type` varchar(50),
            `password_hash` varchar(255) NOT NULL,
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `email` (`email`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

        "CREATE TABLE IF NOT EXISTS `rides` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) NOT NULL,
            `pickup` varchar(200) NOT NULL,
            `dropoff` varchar(200) NOT NULL,
            `lat_pickup` decimal(10,8) DEFAULT NULL,
            `lng_pickup` decimal(11,8) DEFAULT NULL,
            `lat_dropoff` decimal(10,8) DEFAULT NULL,
            `lng_dropoff` decimal(11,8) DEFAULT NULL,
            `status` enum('booked','ongoing','completed','cancelled') DEFAULT 'booked',
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `user_id` (`user_id`),
            FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

        "CREATE TABLE IF NOT EXISTS `matches` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) NOT NULL,
            `matched_user_id` int(11) NOT NULL,
            `status` enum('pending','accepted','rejected') DEFAULT 'pending',
            `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `unique_match` (`user_id`,`matched_user_id`),
            KEY `user_id` (`user_id`),
            KEY `matched_user_id` (`matched_user_id`),
            FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
            FOREIGN KEY (`matched_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;"
    ];

    foreach ($tables as $sql) {
        $pdo->exec($sql);
    }
}

// Profile Creation
function createProfile(array $data): array {
    global $pdo;
    
    $required = ['name', 'email', 'password'];
    foreach ($required as $field) {
        if (empty($data[$field])) {
            throw new InvalidArgumentException("Missing required field: $field");
        }
    }

    // Check if email exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$data['email']]);
    if ($stmt->fetch()) {
        throw new InvalidArgumentException("Email already exists");
    }

    // Hash password
    $hash = password_hash($data['password'], PASSWORD_DEFAULT);
    
    // Insert user
    $stmt = $pdo->prepare("
        INSERT INTO users (name, email, interests, vehicle_type, password_hash) 
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $data['name'],
        $data['email'],
        $data['interests'] ?? null,
        $data['vehicle'] ?? null,
        $hash
    ]);

    $userId = $pdo->lastInsertId();
    $token = generateJWT($userId);

    return [
        'success' => true,
        'user_id' => $userId,
        'token' => $token,
        'message' => 'Profile created successfully'
    ];
}

// Matchmaking
function findMatches(int $userId, string $interests): array {
    global $pdo;
    
    if (empty($interests)) {
        throw new InvalidArgumentException("Interests cannot be empty");
    }

    $stmt = $pdo->prepare("
        SELECT u.id, u.name, u.interests, 
               (LENGTH(u.interests) - LENGTH(REPLACE(u.interests, ?, ''))) / LENGTH(?) as match_score
        FROM users u 
        WHERE u.id != ? 
        AND u.interests LIKE ? 
        AND u.id NOT IN (
            SELECT matched_user_id FROM matches WHERE user_id = ?
            UNION
            SELECT user_id FROM matches WHERE matched_user_id = ?
        )
        ORDER BY match_score DESC 
        LIMIT 10
    ");
    $searchTerm = "%$interests%";
    $stmt->execute([$interests, $interests, $userId, $searchTerm, $userId, $userId]);
    
    $matches = $stmt->fetchAll();
    
    // Add to matches table
    foreach ($matches as $match) {
        $stmt = $pdo->prepare("INSERT IGNORE INTO matches (user_id, matched_user_id, status) VALUES (?, ?, 'pending')");
        $stmt->execute([$userId, $match['id']]);
    }
    
    return $matches;
}

// Book Ride
function bookRide(int $userId, array $data): array {
    global $pdo;
    
    $required = ['pickup', 'dropoff'];
    foreach ($required as $field) {
        if (empty($data[$field])) {
            throw new InvalidArgumentException("Missing required field: $field");
        }
    }

    // Validate coordinates if provided
    if (!empty($data['lat_pickup']) && !is_numeric($data['lat_pickup'])) {
        throw new InvalidArgumentException("Invalid pickup latitude");
    }

    // Insert ride
    $stmt = $pdo->prepare("
        INSERT INTO rides (user_id, pickup, dropoff, lat_pickup, lng_pickup, lat_dropoff, lng_dropoff, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, 'booked')
    ");
    $stmt->execute([
        $userId,
        $data['pickup'],
        $data['dropoff'],
        $data['lat_pickup'] ?? null,
        $data['lng_pickup'] ?? null,
        $data['lat_dropoff'] ?? null,
        $data['lng_dropoff'] ?? null
    ]);

    $rideId = $pdo->lastInsertId();

    // Notify Socket.io
    notifySocketIO('ride_started', ['ride_id' => $rideId, 'user_id' => $userId]);

    return [
        'success' => true,
        'ride_id' => $rideId,
        'message' => 'Ride booked successfully'
    ];
}

// Socket.io notification
function notifySocketIO(string $event, array $data): void {
    try {
        $client = Client::create(Client::createUrl(SOCKET_URL), Version2X::class);
        $client->initialize();
        $client->emit($event, $data);
        $client->close();
    } catch (Exception $e) {
        error_log("Socket.io notification failed: " . $e->getMessage());
    }
}

// Get user's rides
function getUserRides(int $userId): array {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT r.*, u.name as driver_name 
        FROM rides r 
        LEFT JOIN users u ON r.user_id = u.id 
        WHERE r.user_id = ? 
        ORDER BY r.created_at DESC 
        LIMIT 50
    ");
    $stmt->execute([$userId]);
    return $stmt->fetchAll();
}

// API Handler
try {
    $input = json_decode(file_get_contents('php://input'), true) ?: [];
    $action = $_GET['action'] ?? '';
    $token = $_SERVER['HTTP_AUTHORIZATION'] ?? '';

    // Authenticate (except for profile creation)
    $decoded = null;
    if ($action !== 'profile' && $token) {
        $decoded = verifyJWT(str_replace('Bearer ', '', $token));
        if (!$decoded) {
            throw new Exception('Unauthorized');
        }
    }

    $userId = $decoded ? (int)$decoded->user_id : null;

    switch ($action) {
        case 'profile':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Method not allowed');
            }
            $result = createProfile($input);
            break;

        case 'matches':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Method not allowed');
            }
            if (!$userId) {
                throw new Exception('Authentication required');
            }
            $result = ['matches' => findMatches($userId, $input['interests'] ?? '')];
            break;

        case 'ride':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Method not allowed');
            }
            if (!$userId) {
                throw new Exception('Authentication required');
            }
            $result = bookRide($userId, $input);
            break;

        case 'rides':
            if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
                throw new Exception('Method not allowed');
            }
            if (!$userId) {
                throw new Exception('Authentication required');
            }
            $result = ['rides' => getUserRides($userId)];
            break;

        case 'health':
            $result = ['status' => 'healthy', 'timestamp' => time()];
            break;

        default:
            throw new Exception('Invalid action');
    }

    echo json_encode($result);

} catch (Exception $e) {
    http_response_code($e->getCode() ?: 400);
    echo json_encode([
        'error' => $e->getMessage(),
        'timestamp' => time()
    ]);
}