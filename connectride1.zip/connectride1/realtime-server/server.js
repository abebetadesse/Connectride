require('dotenv').config();
const { createServer } = require('http');
const { Server } = require('socket.io');
const { createClient } = require('redis');

const httpServer = createServer();
const io = new Server(httpServer, {
    cors: {
        origin: process.env.FRONTEND_URL || "http://localhost:3000",
        methods: ["GET", "POST"]
    }
});

const redisClient = createClient({ url: process.env.REDIS_URL });

(async () => {
    try {
        await redisClient.connect();
        console.log('Connected to Redis');
    } catch (e) {
        console.error('Failed to connect to Redis', e);
    }
})();

io.on('connection', (socket) => {
    console.log(`User connected: ${socket.id}`);

    // Listen for ride tracking requests
    socket.on('track_ride', async ({ rideId }) => {
        console.log(`User ${socket.id} is tracking ride ${rideId}`);
        socket.join(`ride_${rideId}`);
    });

    // Listen for location updates from the driver (simulated)
    socket.on('update_location', async (data) => {
        const { ride_id, lat, lng } = data;
        if (ride_id && lat && lng) {
            console.log(`Received location update for ride ${ride_id}: lat=${lat}, lng=${lng}`);
            // Broadcast the location update to all users in the specific ride room
            io.to(`ride_${ride_id}`).emit('location_update', {
                ride_id,
                lat,
                lng,
                timestamp: Date.now()
            });
            // Store location in Redis for persistence (e.g., driver history)
            await redisClient.set(`ride_location_${ride_id}`, JSON.stringify({ lat, lng }), { EX: 3600 }); // Expires in 1 hour
        }
    });

    // Listen for ride status updates
    socket.on('ride_status', (data) => {
        const { ride_id, status } = data;
        if (ride_id && status) {
            console.log(`Ride ${ride_id} status updated to: ${status}`);
            io.to(`ride_${ride_id}`).emit('ride_status_update', {
                ride_id,
                status
            });
        }
    });

    socket.on('disconnect', () => {
        console.log(`User disconnected: ${socket.id}`);
    });
});

httpServer.listen(process.env.PORT || 4000, () => {
    console.log(`Realtime server listening on port ${process.env.PORT || 4000}`);
});